BASE_URL = 'http://wp8m3he1wt.s3-website-ap-southeast-2.amazonaws.com'
START_ENDPOINT = '/api/products/1'
